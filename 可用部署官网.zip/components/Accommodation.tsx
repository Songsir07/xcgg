import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Camera, X, UploadCloud, MapPin, Quote, Loader2, Image as ImageIcon, CheckCircle, Zap } from 'lucide-react';
import { SectionId, GuestMoment } from '../types';
import { useGlobalImages } from '../context/ImageContext';
import ImageUploader from './ImageUploader';

// --- Types & Data ---

interface Room {
  id: number;
  image: string;
  title: string; 
}

const ROOMS: Room[] = [
  {
    id: 1,
    title: "云端·代码舱",
    image: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 2,
    title: "山谷·行政墅",
    image: "https://images.unsplash.com/photo-1600596542815-225efc41f471?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 3,
    title: "星空·穹顶屋",
    image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 4,
    title: "森林·树屋",
    image: "https://images.unsplash.com/photo-1449156493391-d2cfa28e468b?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 5,
    title: "湖畔·静修室",
    image: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 6,
    title: "未来·实验室",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 7,
    title: "悬崖·冥想台",
    image: "https://images.unsplash.com/photo-1449844908441-8829872d2607?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 8,
    title: "竹林·隐士居",
    image: "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 9,
    title: "溪流·创客空间",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=2000",
  },
  {
    id: 10,
    title: "茶园·全景房",
    image: "https://images.unsplash.com/photo-1510784722466-f2aa9c52fff6?auto=format&fit=crop&q=80&w=2000",
  }
];

// --- Smart Captions Generator ---
const TECH_POETRY = [
  "Commit: 把灵魂提交给山野。",
  "404: 城市喧嚣未找到。",
  "System.out.print('宁静');",
  "正在编译这一刻的云...",
  "在 500 英亩森林中 Debug 人生。",
  "带宽 10Gbps，心率 60bpm。",
  "这是我的 Source Code。",
  "Esc: 退出循环。",
  "Git push origin life --force",
  "运行环境：纯净自然。",
  "Hello World, Hello Valley.",
  "算法的尽头是这片森林。"
];

const getRandomCaption = () => {
  return TECH_POETRY[Math.floor(Math.random() * TECH_POETRY.length)];
};

// --- Sub-Components ---

const MarqueeRow: React.FC<{ moments: GuestMoment[]; direction: 'left' | 'right'; speed?: number }> = ({ moments, direction, speed = 20 }) => {
  if (moments.length === 0) return null;
  
  // Clone items to ensure seamless loop
  const items = moments.length < 5 
    ? [...moments, ...moments, ...moments, ...moments, ...moments, ...moments] 
    : [...moments, ...moments, ...moments];

  return (
    <div className="flex overflow-hidden relative w-full py-4 group">
      <motion.div
        className="flex gap-4 min-w-full"
        initial={{ x: direction === 'left' ? 0 : '-50%' }}
        animate={{ x: direction === 'left' ? '-50%' : 0 }}
        transition={{ duration: speed, repeat: Infinity, ease: "linear" }}
      >
        {items.map((moment, idx) => (
          <div 
            key={`${moment.id}-${idx}`} 
            className="relative flex-shrink-0 w-[280px] h-[360px] md:w-[320px] md:h-[420px] rounded-xl overflow-hidden cursor-pointer group/item bg-gray-100 dark:bg-white/5 shadow-md border border-gray-100 dark:border-white/5"
          >
            <img 
              src={moment.image} 
              alt="Moment" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover/item:scale-110 grayscale-[10%] group-hover/item:grayscale-0"
              loading="lazy"
            />
            {/* Minimal overlay, auto-generated caption */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover/item:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                 <p className="text-white font-medium text-lg leading-snug font-serif mb-1">{moment.caption}</p>
                 <div className="flex items-center gap-2 text-white/70 text-xs uppercase tracking-widest font-medium">
                    <MapPin size={12} />
                    <span>{moment.location}</span>
                 </div>
            </div>
          </div>
        ))}
      </motion.div>
      <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-white dark:from-black to-transparent z-10 pointer-events-none"></div>
      <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-white dark:from-black to-transparent z-10 pointer-events-none"></div>
    </div>
  );
};

interface UploadModalProps {
  onClose: () => void;
}

const UploadModal: React.FC<UploadModalProps> = ({ onClose }) => {
  const { addMoment } = useGlobalImages();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [status, setStatus] = useState<'idle' | 'compressing' | 'saving' | 'success'>('idle');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(selectedFile);
      setFile(selectedFile);
    }
  };

  const handleDirectPublish = async () => {
    if (!file) return;
    
    try {
      setStatus('compressing');
      await new Promise(r => setTimeout(r, 500)); // UI feedback
      
      setStatus('saving');
      
      // Auto-fill metadata for "Direct Publish" experience
      await addMoment({
        id: Date.now().toString(),
        caption: getRandomCaption(), // Auto-generate poetic caption
        location: "乡村硅谷 · 影像库",
        author: "匿名极客", 
        timestamp: Date.now()
      }, file);

      setStatus('success');
      
      setTimeout(() => {
        onClose();
      }, 1500);

    } catch (e) {
      console.error(e);
      alert("上传失败，请重试");
      setStatus('idle');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }} 
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white dark:bg-[#1c1c1e] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-gray-200 dark:border-white/10"
      >
        <div className="p-6 border-b border-gray-100 dark:border-white/5 flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white font-serif">
            {status === 'success' ? '发布成功' : '一键发布'}
          </h3>
          <button onClick={onClose} disabled={status !== 'idle' && status !== 'success'}><X className="text-gray-500" /></button>
        </div>
        
        {status === 'success' ? (
           <div className="p-12 flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center mb-6">
                <CheckCircle size={40} />
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">已永久绑定</h4>
              <p className="text-gray-500 text-sm">影像已存入硅谷核心数据库。</p>
           </div>
        ) : (
          <div className="p-6 space-y-6">
            {!preview ? (
              <div className="relative border-2 border-dashed border-gray-300 dark:border-white/20 rounded-2xl h-64 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors cursor-pointer group">
                <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                <div className="w-16 h-16 bg-gray-100 dark:bg-white/10 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <UploadCloud size={32} />
                </div>
                <span className="text-base font-medium">点击选择照片</span>
                <span className="text-xs text-gray-400 mt-2">智能压缩 · 永久保存 · 自动配文</span>
              </div>
            ) : (
              <div className="relative h-64 rounded-2xl overflow-hidden group shadow-lg">
                <img src={preview} className="w-full h-full object-cover" />
                <button onClick={() => { setPreview(''); setFile(null); }} className="absolute top-2 right-2 bg-black/60 text-white p-2 rounded-full hover:bg-red-500 transition-colors backdrop-blur-md">
                    <X size={16}/>
                </button>
              </div>
            )}
            
            {/* Direct Action Button - No Input Fields */}
            <button 
              onClick={handleDirectPublish} 
              disabled={!preview || status !== 'idle'}
              className="w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-xl font-bold text-lg hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2 shadow-xl transition-all active:scale-95"
            >
              {status === 'compressing' ? (
                <> <Loader2 className="animate-spin" /> 智能处理中... </>
              ) : status === 'saving' ? (
                <> <Loader2 className="animate-spin" /> 写入数据库... </>
              ) : (
                <> <Zap size={20} fill="currentColor" /> 立即发布 </>
              )}
            </button>
            
            <p className="text-center text-xs text-gray-400">
               "在这个充满 bug 的世界里，只有这瞬间是 feature。"
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

// --- Main Component ---

const Accommodation: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  
  // Use persistent moments from Context
  const { getImage, isEditMode, moments } = useGlobalImages();

  // Auto-play Logic for Top Slider
  useEffect(() => {
    if (isPaused || isEditMode) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ROOMS.length);
    }, 5000); 
    return () => clearInterval(timer);
  }, [isPaused, isEditMode]);

  const handleNext = () => setCurrentIndex((prev) => (prev + 1) % ROOMS.length);
  const handlePrev = () => setCurrentIndex((prev) => (prev - 1 + ROOMS.length) % ROOMS.length);

  // Get current room image dynamically
  const currentRoom = ROOMS[currentIndex];
  const roomImageId = `room-img-${currentRoom.id}`;
  const roomImageSrc = getImage(roomImageId, currentRoom.image);

  return (
    <section id={SectionId.ACCOMMODATION} className="relative w-full bg-white dark:bg-black">
      
      {/* ---------------- PART 1: The Immersive Slider ---------------- */}
      <div 
        className="relative h-screen w-full overflow-hidden group"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentRoom.id}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.2, ease: "easeInOut" }}
            className="absolute inset-0 z-0"
          >
            <img 
              src={roomImageSrc} 
              alt={currentRoom.title} 
              className="w-full h-full object-cover"
            />
            {/* Image Uploader enabled for this slot - Persists via ImageContext */}
            <ImageUploader id={roomImageId} />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none"></div>
          </motion.div>
        </AnimatePresence>

        {/* Minimal Navigation Controls */}
        <div className="absolute bottom-12 right-12 z-20 flex flex-col items-end gap-6 pointer-events-auto">
           {/* Progress Bar / Dots */}
           <div className="flex gap-2">
              {ROOMS.map((_, idx) => (
                 <button 
                   key={idx}
                   onClick={() => setCurrentIndex(idx)}
                   className={`h-1.5 rounded-full transition-all duration-500 shadow-sm ${idx === currentIndex ? 'w-12 bg-white' : 'w-4 bg-white/40 hover:bg-white/80'}`}
                 />
              ))}
           </div>
           
           {/* Arrows */}
           <div className="flex gap-4">
              <button onClick={handlePrev} className="w-14 h-14 rounded-full border border-white/20 bg-black/10 backdrop-blur-md text-white flex items-center justify-center hover:bg-white hover:text-black transition-all duration-300">
                <ChevronLeft size={24} />
              </button>
              <button onClick={handleNext} className="w-14 h-14 rounded-full border border-white/20 bg-black/10 backdrop-blur-md text-white flex items-center justify-center hover:bg-white hover:text-black transition-all duration-300">
                <ChevronRight size={24} />
              </button>
           </div>
        </div>
      </div>

      {/* ---------------- PART 2: The Lifestyle Gallery (Persistent) ---------------- */}
      <div className="relative py-24 bg-white dark:bg-[#050505] overflow-hidden">
        
        <div className="max-w-7xl mx-auto px-6 mb-16 flex flex-col md:flex-row items-end justify-between gap-8">
           <div className="max-w-2xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <span className="h-px w-12 bg-black dark:bg-white opacity-50"></span>
                  <span className="text-xs font-bold uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Community Gallery</span>
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 dark:text-white mb-6">
                  山谷·居住剪影
                </h2>
                <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed font-light">
                  不仅是住宿，更是生活方式的共鸣。在这里，遇见代码之外的诗意。
                </p>
              </motion.div>
           </div>

           <motion.button
             whileHover={{ scale: 1.05 }}
             whileTap={{ scale: 0.95 }}
             onClick={() => setIsUploadOpen(true)}
             className="flex items-center gap-3 px-8 py-4 bg-black dark:bg-white text-white dark:text-black rounded-full font-bold shadow-xl hover:shadow-2xl transition-all"
           >
             <Camera size={20} />
             <span>一键上传</span>
           </motion.button>
        </div>

        <div className="space-y-8 min-h-[400px]">
          {/* Automatically loads 'moments' from ImageContext (IndexedDB) */}
          {moments.length > 0 ? (
            <>
              <MarqueeRow moments={moments} direction="left" speed={40} />
              <MarqueeRow moments={moments} direction="right" speed={50} />
            </>
          ) : (
             <div className="max-w-7xl mx-auto px-6">
                <div 
                  onClick={() => setIsUploadOpen(true)}
                  className="w-full h-80 border-2 border-dashed border-gray-200 dark:border-white/10 rounded-3xl flex flex-col items-center justify-center text-gray-400 dark:text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5 transition-all cursor-pointer gap-4 group"
                >
                    <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                       <ImageIcon size={32} />
                    </div>
                    <p className="text-lg font-medium">暂无照片</p>
                    <p className="text-sm opacity-60">数据正在从云端数据库同步，或您可以成为第一个分享者。</p>
                </div>
             </div>
          )}
        </div>

        <div className="mt-20 text-center max-w-3xl mx-auto px-6">
           <Quote className="mx-auto text-gray-300 dark:text-gray-700 mb-6 w-12 h-12" />
           <p className="text-2xl md:text-3xl font-serif italic text-gray-800 dark:text-gray-200 leading-relaxed">
             "在乡村硅谷，我在清晨的鸟鸣中写下了最优雅的算法。这里的每一扇窗，都是一副风景画。"
           </p>
           <div className="mt-6 flex items-center justify-center gap-3">
             <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="User" />
             </div>
             <div className="text-left">
                <div className="text-sm font-bold text-gray-900 dark:text-white">Felix W.</div>
                <div className="text-xs text-gray-500">Full Stack Developer</div>
             </div>
           </div>
        </div>

      </div>

      <AnimatePresence>
        {isUploadOpen && (
          <UploadModal onClose={() => setIsUploadOpen(false)} />
        )}
      </AnimatePresence>

    </section>
  );
};

export default Accommodation;