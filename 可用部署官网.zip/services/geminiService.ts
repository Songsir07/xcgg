import { GoogleGenAI } from "@google/genai";

// Ensure we handle cases where the key might be undefined or empty string
const apiKey = process.env.API_KEY;

export const sendMessageToGemini = async (
  message: string,
  history: { role: string; parts: { text: string }[] }[]
): Promise<string> => {
  // 1. Safety Check: If no API Key is configured
  if (!apiKey || apiKey === 'undefined' || apiKey.trim() === '') {
    // Return a simulated response so the UI doesn't break
    return "【系统提示】目前处于演示模式，尚未连接至 Neural Core (API Key 未配置)。\n\n虽然我的大脑暂时离线，但您可以继续浏览我们美丽的网站。如果您是管理员，请在部署平台 (如 Vercel) 的环境变量中添加 API_KEY 以激活我。";
  }

  try {
    // 2. Initialize client only when needed and key exists
    const ai = new GoogleGenAI({ apiKey });
    
    const model = 'gemini-3-flash-preview';
    const systemInstruction = `你代表“乡村硅谷” (Rural Silicon Valley) 的 AI 大使。
    我们是一家独特的公司，将高科技 AI 开发与宁静的自然隐居相结合。
    
    核心亮点与新闻：
    1. **政企合作**：我们与衢州市政府深度合作，共建 AI 教育示范区。
    2. **AI 平权**：我们致力于消除数字鸿沟，定期举办公益培训，教村民和孩子使用 AI 工具。
    3. **业务服务**：面向工程团队的封闭式开发隐居（深度工作营）、面向数字游民的极简奢华民宿、AI 研究孵化器。
    
    基调：专业、严谨、具有社会责任感、同时保持 Apple 风格的极简与优雅。
    请务必使用中文回答，保持回答简洁优雅。`;

    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction,
      },
      history: history as any,
    });

    const result = await chat.sendMessage({ message });
    return result.text || "我正在冥想这个想法。请稍后再试。";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "我们的神经链接暂时受到干扰（可能是网络问题或额度限制）。请稍后再试，或直接浏览网页内容。";
  }
};